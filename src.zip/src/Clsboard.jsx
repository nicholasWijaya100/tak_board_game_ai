import React, { useState, useEffect } from "react";
import global from './Global'

export class Clsboard {

  constructor(giliran, arr) {
    this.giliran = giliran;
    this.arr = arr;
  }

  // putKoin(giliran, result) {
  //   var brs = result['brs']; 
  //   var klm = result['klm']; 
  //   var koin = result['koin']; 
  //   this.arr[brs][klm].push(koin); 
  // }
}